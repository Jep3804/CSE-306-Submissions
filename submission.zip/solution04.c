#include <stdio.h>
#include <stdlib.h>

double a(double r, double s, double t) {
   int arr[12] = {144};
   return r*s*t*arr[3];
} 

int* b() {
  int* xp = malloc(sizeof(int));
  *xp = 4;
  printf("*xp is %d\n",*xp);
  return xp;
}

int main() {
  int* y = b();
  printf("y is %d\n",*y);
  
  a(1.2,3.4,5.6);
  
  printf("y is %d\n",*y);
  free(y);
  y = b();
  printf("y is %d\n",*y);
  free(y);
  return 0;
}
