#include <stdio.h>


void b(int x) {
  int sum = 0;
  sum = sum + x;
  printf("sum is %d\n",sum);
}

int main() {
  b(5);
  b(10);
  b(15);
  return 0;
}
