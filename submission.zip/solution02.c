#include <stdio.h>

int a(double x, char y) {
  int z = (int) (y + x);
  return z;
}

void b(int n) {
  int sum = 0;
  for (int i=0; i<n; i++) {
    printf("%d: sum is %d\n",i,sum);
    sum = sum + i;
  }
  printf("final sum is %d\n",sum);
}

int main() {
  a(4.5, 'a');
  b(4);
  b(4);
  return 0;
}
